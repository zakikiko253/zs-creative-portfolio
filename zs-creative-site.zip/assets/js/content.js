/* ZS Creative — all editable content lives here.
   Empty values are simply not shown on the site (no dead links). */
window.ZS_CONTENT = {
  email: "",                      // e.g. "hello@yourdomain.com"
  social: {                       // full URLs, e.g. "https://instagram.com/yourhandle"
    Instagram: "",
    Facebook: "",
    TikTok: "",
    Behance: "",
    LinkedIn: ""
  },
  /* image: "assets/img/file.jpg" (optional, shown instead of the typographic cover)
     alt: describes the image
     case: optional { Challenge, Approach, "Creative Direction", Execution, "Final Result" }
     Only fill in what is true. Without "case", the panel shows a short summary. */
  projects: [
    { name: "Mimi Clown", category: "Content & Branding", year: "", description: "", image: "", alt: "", case: null },
    { name: "Team Chadli", category: "Visual Content", year: "", description: "", image: "", alt: "", case: null },
    { name: "Numidia Phone", category: "Digital Strategy", year: "", description: "", image: "", alt: "", case: null },
    { name: "Insati", category: "Brand Identity", year: "", description: "", image: "", alt: "", case: null },
    { name: "Photography / Amar Dafi", category: "Photography", year: "", description: "", image: "", alt: "", case: null },
    { name: "ZS Creative Branding", category: "Brand Identity", year: "", description: "", image: "", alt: "", case: null }
  ]
};
