# ZS Creative — Portfolio

Static site (HTML, CSS, vanilla JS). No build step.

## Edit content
Everything editable is in `assets/js/content.js`: email, social URLs, projects, images, case studies.
Empty values are hidden automatically. Put images in `assets/img/` and set `image` and `alt`.

## Run locally
`npx serve .` (or open `index.html`; the contact form only works on Netlify).

## Deploy
1. `git init && git add . && git commit -m "ZS Creative site"`, then push to GitHub.
2. Netlify: Add new site, Import from Git, choose the repo. Build command: empty. Publish directory: `.`
3. Contact form: after the first deploy, Netlify Forms picks up the `contact` form. Enable email notifications under Site settings, Forms.
4. Add your domain and, if you want, a `sitemap.xml` and `og:image` once the domain is known.
